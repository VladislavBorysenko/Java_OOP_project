package com.android.school.oop;

public class Fish extends Animal{

    @Override
    public void move(){
        System.out.println("swim");
    }
}
