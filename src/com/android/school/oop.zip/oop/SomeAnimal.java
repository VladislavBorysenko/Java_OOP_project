package com.android.school.oop;

public class SomeAnimal extends Animal{
}
