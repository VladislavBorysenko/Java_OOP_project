package com.android.school.oop;

public class Animal {

    public void move(){
        System.out.println("animal move");
    }
}
