package com.android.school.oop;

public class Bird extends Animal{

    @Override
    public  void move(){
        System.out.println("fly");
    }
}
